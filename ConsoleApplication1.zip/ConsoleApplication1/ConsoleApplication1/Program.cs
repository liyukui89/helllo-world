﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class mathOpr1
    {

        public   int Add(params int[] nums)
        {
            int sum = 0;
            for (int i = 0; i < nums.Length; i++)
                sum = sum + nums[i];
            return sum;
        }
        public void   getVolume()
        {
            Console.WriteLine(Add(3, 6));
        }
    }

    class mathOpr
    {
        static void Main(string[] args)
        {
            mathOpr1 test = new mathOpr1();
            test.getVolume();
            //Console.WriteLine(Add(3, 6));



            Console.ReadLine();

        }
    }
}
